<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Product;
use App\categories;

class FrontendHomeController extends Controller
{
 function Frontendhome(){
 	$premum_product = Product::orderBy('id','desc')->get();
	 $categories = categories::all();
	 $product = Product::all();
    return view('frontend.index',compact('premum_product','categories','product'));
 }


 

 // Click কারার পরে product Details Single Page এ দেখানোর জনে

function productDetails($product_id){
	$single_product_info = Product::findOrFail($product_id);
	// রিলেটেড Product দেখানোর জনে  single product এর id অনুযায়ী
	// category_p_id এটা product Table এর কলামের নাম

	$related_product = Product::where('id', '!=',$product_id)->where('category_p_id', $single_product_info->category_p_id)->get();

 return view('frontend.Show_Single_product',compact('single_product_info','related_product'));
}


// Click কারার পরে product Details Single Page এ দেখানোর জনে

// Route::get('/product/Details/{product_id}','FrontendHomeController@productDetails');

// যেখানে বা Single Product Open করার জনে যে পেজ ডিজাইন করা আছে সেখানে
// <h2>{{ $single_product_info->Product_Name }}</h2>
// single_product_info এটা Controller থেকে  Product_Name টেবিলের কলামের নাম


// ক্লিক করলেই যাতে single page এ খোলে তার জনে এই কোড

// <a href="{{ url('/product/Details') }}/{{ $premum_product->id }}">
// <figure>
//    <img src="{{ asset('/frontend/img/intro/1.jpg') }}" alt="#">
// </figure>
// </a>

// এবং Show_Single_product.blade পেজে কিছু কাজ আছে

// Category wise product show
 function categorywiseproduct($category_id){
	$products = product::where('category_p_id', $category_id)->get();
return view('frontend.categorywiseproduct', compact('products'));

 }

//  category_p_id এর product টেবিলের কলাম যার id category টেবিল থেকে আসছে integer
}
