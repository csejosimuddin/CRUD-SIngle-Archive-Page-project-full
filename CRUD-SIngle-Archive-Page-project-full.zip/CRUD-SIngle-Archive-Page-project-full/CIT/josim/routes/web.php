<?php



// Route::get('/', function () {
//     return view('welcome');
// });



// FrontEnd Route Section

Route::get('/','FrontendHomeController@Frontendhome');
// Click কারার পরে product Details Single Page এ দেখানোর জনে
Route::get('/product/Details/{product_id}','FrontendHomeController@productDetails');


Auth::routes();
Route::get('/home', 'HomeController@index')->name('home');




// Backend Route Section

// Product Route
Route::get('/Add/Product/View','ProductController@index');
Route::post('/add/product/insert','ProductController@addproductinsert');
// Delete Route
Route::get('/delete/product/{product_id}','ProductController@deleteproduct');
// Edit করার সময় ডাটাগুলা শো করার জনে Route
Route::get('/edit/product/{product_id}','ProductController@editproduct');
// Edit করে ডাটা যুকত করার জনে
Route::post('/edit/product/insert','ProductController@editproductinsert');
// ডিলিট করা ডাটাগুলে Restor করার জনে
Route::get('/restore/product/{product_id}','ProductController@restore_product');
// ডিলিট করা ডাটাগুলে Permantly Delete করার জনে
Route::get('/permantlyDelete/product/{product_id}','ProductController@permantlyDeleteProduct');


// Category Route Section

Route::get('/Add/category/View','CategoriesController@index');
Route::post('/add/category/insert','CategoriesController@addcategoryinsert');


// Archive  Route

Route::get('category/wise/product/{category_id}','FrontendHomeController@categorywiseproduct');
