<!DOCTYPE html>
<html lang="zxx">

<!-- Mirrored from preview.colorlib.com/theme/theplaza/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 01 Apr 2021 05:09:03 GMT -->
<head>
<title>The Plaza - eCommerce Template</title>
<meta charset="UTF-8">
<meta name="description" content="The Plaza eCommerce Template">
<meta name="keywords" content="plaza, eCommerce, creative, html">
<meta name="viewport" content="width=device-width, initial-scale=1.0">

<link href="img/favicon.ico" rel="shortcut icon" />

<link href="https://fonts.googleapis.com/css?family=Raleway:400,400i,500,500i,600,600i,700,700i" rel="stylesheet">

<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/bootstrap.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/font-awesome.min.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/owl.carousel.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/style.css')); ?>" />
<link rel="stylesheet" href="<?php echo e(asset('/frontend/css/animate.css')); ?>" />
<!--[if lt IE 9]>
	  <script src="https://oss.maxcdn.com/html5shiv/3.7.2/html5shiv.min.js"></script>
	  <script src="https://oss.maxcdn.com/respond/1.4.2/respond.min.js"></script>
	<![endif]-->
</head>
<body>

<div id="preloder">
<div class="loader"></div>
</div>

<header class="header-section">
<div class="container-fluid">

<div class="site-logo">
<img src="<?php echo e(asset('frontend/img/logo.png')); ?>" alt="logo">
</div>

<div class="nav-switch">
<i class="fa fa-bars"></i>
</div>
<div class="header-right">
<a href="cart.html" class="card-bag"><img src="img/icons/bag.png" alt=""><span>2</span></a>
<a href="#" class="search"><img src="img/icons/search.png" alt=""></a>
</div>

<!-- Controller ছাড়া ডাইরেক্ট blade.php তে controller কে যুকত করে foreach loop 
চালানোর জনে 
এখানে category থেকে মেনু ডাইনামকলি নিয়ে আসব -->

<ul class="main-menu">
<?php
$jkononame = App\categories::latest()->take(2)->get();
?>

<li><a href="<?php echo e(url('/')); ?>">Home</a></li>
<?php $__currentLoopData = $jkononame; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<li><a href="<?php echo e(url('category/wise/product')); ?>/<?php echo e($menu->id); ?>"><?php echo e($menu->category_id); ?></a></li>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<!-- category_id এটা categories টেবিলের কলামের নাম -->

<li><a href="<?php echo e(url('/home')); ?>">Dashbord</a></li>
</ul>
</div>
</header>



<?php echo $__env->yieldContent('content'); ?>










<section class="footer-top-section home-footer">
<div class="container">
<div class="row">
<div class="col-lg-3 col-md-8 col-sm-12">
<div class="footer-widget about-widget">
<img src="img/logo.png" class="footer-logo" alt="">
<p>Donec vitae purus nunc. Morbi faucibus erat sit amet congue mattis. Nullam fringilla faucibus urna, id dapibus erat iaculis ut. Integer ac sem.</p>
<div class="cards">
<img src="img/cards/5.png" alt="">
<img src="img/cards/4.png" alt="">
<img src="img/cards/3.png" alt="">
<img src="img/cards/2.png" alt="">
<img src="img/cards/1.png" alt="">
</div>
</div>
</div>
<div class="col-lg-2 col-md-4 col-sm-6">
<div class="footer-widget">
<h6 class="fw-title">usefull Links</h6>
<ul>
<li><a href="#">Partners</a></li>
<li><a href="#">Bloggers</a></li>
<li><a href="#">Support</a></li>
<li><a href="#">Terms of Use</a></li>
<li><a href="#">Press</a></li>
</ul>
</div>
</div>
<div class="col-lg-2 col-md-4 col-sm-6">
<div class="footer-widget">
<h6 class="fw-title">Sitemap</h6>
<ul>
<li><a href="#">Partners</a></li>
<li><a href="#">Bloggers</a></li>
<li><a href="#">Support</a></li>
<li><a href="#">Terms of Use</a></li>
<li><a href="#">Press</a></li>
</ul>
</div>
</div>
<div class="col-lg-2 col-md-4 col-sm-6">
<div class="footer-widget">
<h6 class="fw-title">Shipping & returns</h6>
<ul>
<li><a href="#">About Us</a></li>
<li><a href="#">Track Orders</a></li>
<li><a href="#">Returns</a></li>
<li><a href="#">Jobs</a></li>
<li><a href="#">Shipping</a></li>
<li><a href="#">Blog</a></li>
</ul>
</div>
</div>
<div class="col-lg-2 col-md-4 col-sm-6">
<div class="footer-widget">
<h6 class="fw-title">Contact</h6>
<div class="text-box">
<p>Your Company Ltd </p>
<p>1481 Creekside Lane Avila Beach, CA 93424, </p>
<p>+53 345 7953 32453</p>
<p><a href="https://preview.colorlib.com/cdn-cgi/l/email-protection" class="__cf_email__" data-cfemail="016e676768626441786e7473646c60686d2f626e6c">[email&#160;protected]</a></p>
</div>
</div>
</div>
</div>
</div>
</section>


 <footer class="footer-section">
<div class="container">
<p class="copyright">

Copyright &copy;<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script><script>document.write(new Date().getFullYear());</script> All rights reserved | This template is made with <i class="fa fa-heart-o" aria-hidden="true"></i> by <a href="https://colorlib.com/" target="_blank">Colorlib</a>

</p>
</div>
</footer>


<script src="<?php echo e(asset('/frontend/js/jquery-3.2.1.min.js')); ?>"></script>
<script src="<?php echo e(asset('/frontend/js/bootstrap.min.js')); ?>"></script>
<script src="<?php echo e(asset('/frontend/js/owl.carousel.min.js')); ?>"></script>
<script src="<?php echo e(asset('/frontend/js/mixitup.min.js')); ?>"></script>
<script src="<?php echo e(asset('/frontend/js/sly.min.js')); ?>"></script>
<script src="<?php echo e(asset('/frontend/js/jquery.nicescroll.min.js')); ?>"></script>
<script src="<?php echo e(asset('/frontend/js/main.js')); ?>"></script>
</body>

<!-- Mirrored from preview.colorlib.com/theme/theplaza/ by HTTrack Website Copier/3.x [XR&CO'2014], Thu, 01 Apr 2021 05:09:17 GMT -->
</html><?php /**PATH C:\Users\Josim Uddin\Desktop\CIT\josim\resources\views/layouts/master.blade.php ENDPATH**/ ?>